// Shopping Cart System
let cart = [];

document.addEventListener('DOMContentLoaded', () => {
    // Cart operations
    updateCartCount();

    // Search logic
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            const productCards = document.querySelectorAll('.product-card');
            
            productCards.forEach(card => {
                const title = card.querySelector('.product-title').textContent.toLowerCase();
                const desc = card.querySelector('.product-desc').textContent.toLowerCase();
                if (title.includes(query) || desc.includes(query)) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }
});

function toggleCart() {
    const modal = document.getElementById('cart-modal');
    modal.classList.toggle('open');
}

function addToCart(name, price) {
    const existingItem = cart.find(item => item.name === name);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ name, price, quantity: 1 });
    }
    updateCartCount();
    renderCartItems();
    alert(`${name} sepete eklendi.`);
}

function updateCartCount() {
    const countElement = document.getElementById('cart-count');
    if (countElement) {
        const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);
        countElement.textContent = totalItems;
    }
}

function renderCartItems() {
    const container = document.getElementById('cart-items-container');
    const totalValElement = document.getElementById('cart-total-value');
    if (!container) return;

    container.innerHTML = '';
    let total = 0;

    cart.forEach((item, index) => {
        total += item.price * item.quantity;
        const itemEl = document.createElement('div');
        itemEl.className = 'cart-item';
        itemEl.innerHTML = `
            <div class="cart-item-detail">
                <h4>${item.name}</h4>
                <p>${item.quantity} x ${item.price} TL</p>
            </div>
            <span class="remove-item" onclick="removeFromCart(${index})">Sil</span>
        `;
        container.appendChild(itemEl);
    });

    if (totalValElement) {
        totalValElement.textContent = total + ' TL';
    }
}

function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartCount();
    renderCartItems();
}

function handleContactSubmit(event) {
    event.preventDefault();
    const name = document.getElementById('contact-name').value;
    alert(`Teşekkürler ${name}! Mesajınız başarıyla iletildi.`);
    event.target.reset();
    return false;
}

function handleNewsletterSubmit(event) {
    event.preventDefault();
    alert('Bültene başarıyla kayıt oldunuz. Teşekkürler!');
    event.target.reset();
    return false;
}
